public abstract class DecoratedDrink{
	public String type;
	protected double price;

	public abstract double getPrice();
}
